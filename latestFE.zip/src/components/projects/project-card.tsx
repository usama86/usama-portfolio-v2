"use client";

import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Project } from "./types";

type Props = {
  project: Project;
  onOpen: () => void;
  featured?: boolean;
};

export function ProjectCard({ project, onOpen, featured }: Props) {
  const cover = project.images?.[0];

  return (
    <button
      onClick={onOpen}
      className="text-left w-full group"
      type="button"
    >
      <Card className="relative overflow-hidden border bg-background/40 transition-all duration-300 group-hover:-translate-y-1 group-hover:shadow-xl">
        {/* glow */}
        <div className="pointer-events-none absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="absolute -top-24 -right-24 h-56 w-56 rounded-full blur-3xl bg-primary/20" />
        </div>

        <CardContent className="p-5 space-y-4">
          <div className="flex items-start gap-4">
            {cover ? (
              <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded-xl border bg-background">
                <Image
                  src={cover}
                  alt={project.title}
                  fill
                  className="object-cover"
                />
              </div>
            ) : null}

            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-base md:text-lg font-semibold leading-tight">
                  {project.title}
                </h3>
                {featured ? (
                  <Badge className="rounded-full" variant="secondary">
                    Featured
                  </Badge>
                ) : null}
              </div>

              {(project.company || project.timePeriod) && (
                <p className="text-sm text-muted-foreground mt-1">
                  {project.company ?? ""}
                  {project.company && project.timePeriod ? " • " : ""}
                  {project.timePeriod ?? ""}
                </p>
              )}
            </div>
          </div>

          {!!project.technologies?.length && (
            <div className="flex flex-wrap gap-2">
              {project.technologies.slice(0, featured ? 10 : 6).map((t) => (
                <Badge key={t} variant="outline" className="rounded-full">
                  {t}
                </Badge>
              ))}
            </div>
          )}

          <p className="text-sm text-foreground/80 line-clamp-2">
            {project.descriptionDetail?.[0] ?? ""}
          </p>
        </CardContent>
      </Card>
    </button>
  );
}
