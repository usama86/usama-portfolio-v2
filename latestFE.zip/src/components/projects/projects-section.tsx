"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { projects } from "@/data/projects";
import type { Project } from "@/components/projects/types";
import { ProjectCard } from "@/components/projects/project-card";
import { ProjectDialog } from "@/components/projects/project-dialog";

const FEATURED_SLUGS = new Set([
  "cleon-ai-voice-ordering",
  "query-builder",
]);

export function ProjectsSection() {
  const router = useRouter();
  const [open, setOpen] = React.useState(false);
  const [active, setActive] = React.useState<Project | null>(null);

  const featured = projects.filter((p) => FEATURED_SLUGS.has(p.slug));
  const more = projects.filter((p) => !FEATURED_SLUGS.has(p.slug));

  function openProject(p: Project) {
    setActive(p);
    setOpen(true);
  }

  return (
    <section className="space-y-6">
      <div className="space-y-2">
        <h2 className="text-2xl md:text-3xl font-semibold">Projects</h2>
        <p className="text-sm md:text-base text-muted-foreground max-w-2xl">
          Real products, real systems — from multi-tenant SaaS to AI voice agents and large-scale UI platforms.
        </p>
      </div>

      {/* Featured */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold">Featured</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {featured.map((p) => (
            <ProjectCard
              key={p.slug}
              project={p}
              featured
              onOpen={() => openProject(p)}
            />
          ))}
        </div>
      </div>

      {/* More */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold">More</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {more.map((p) => (
            <ProjectCard
              key={p.slug}
              project={p}
              onOpen={() => openProject(p)}
            />
          ))}
        </div>
      </div>

      {/* Modal */}
      <ProjectDialog
        open={open}
        onOpenChange={setOpen}
        project={active}
        onViewCaseStudy={(slug) => {
          setOpen(false);
          router.push(`/projects/${slug}`);
        }}
      />
    </section>
  );
}
