import { ProjectsSection } from "@/components/projects/projects-section";

export default function Page() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-10">
      <ProjectsSection />
    </main>
  );
}
